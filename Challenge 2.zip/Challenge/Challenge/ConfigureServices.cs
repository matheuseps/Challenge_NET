﻿using Challenge.Repositories;
using Challenge.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using System.Configuration;

public void ConfigureServices(IServiceCollection services)
{
    // Configura o DbContext com a string de conexão
    services.AddDbContext<ApplicationDbContext>(options =>
        options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

    // Adiciona os serviços de repositório e serviço
    services.AddScoped<IProblemaRepository, ProblemaRepository>();
    services.AddScoped<IUsuarioRepository, UsuarioRepository>();
    services.AddScoped<ICadastroRepository, CadastroRepository>();

    services.AddScoped<IProblemaService, ProblemaService>();
    services.AddScoped<IUsuarioService, UsuarioService>();
    services.AddScoped<ICadastroService, CadastroService>();

    // Configura a autenticação e autorização
    services.AddAuthorization();
    services.AddControllers();

    // Configura o Swagger para a documentação da API
    services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo
        {
            Title = "API Challenge",
            Version = "v1",
            Description = "API para resolver problemas de cadastro e usuários.",
            Contact = new OpenApiContact
            {
                Name = "Seu Nome",
                Email = "seu.email@exemplo.com"
            }
        });
    });
}
