using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Xunit;

public class AuthServiceTests
{
	private readonly string _validToken = "valid-jwt-token";
	private readonly string _username = "testuser";
	private readonly string _password = "testpassword";

	[Fact]
	public async Task LoginAsync_ShouldReturnToken_WhenCredentialsAreValid()
	{
		
		var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

		handlerMock
		   .Protected()
		   .Setup<Task<HttpResponseMessage>>(
			  "SendAsync",
			  ItExpr.IsAny<HttpRequestMessage>(),
			  ItExpr.IsAny<CancellationToken>()
		   )
		   .ReturnsAsync(new HttpResponseMessage
		   {
			   StatusCode = HttpStatusCode.OK,
			   Content = new StringContent(JsonConvert.SerializeObject(new { token = _validToken }), Encoding.UTF8, "application/json")
		   });

		var httpClient = new HttpClient(handlerMock.Object);
		var authService = new AuthService(httpClient);

		
		var token = await authService.LoginAsync(_username, _password);

		
		Assert.Equal(_validToken, token);
	}

	[Fact]
	public async Task LoginAsync_ShouldThrowException_WhenCredentialsAreInvalid()
	{
		
		var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

		
		handlerMock
		   .Protected()
		   .Setup<Task<HttpResponseMessage>>(
			  "SendAsync",
			  ItExpr.IsAny<HttpRequestMessage>(),
			  ItExpr.IsAny<CancellationToken>()
		   )
		   .ReturnsAsync(new HttpResponseMessage
		   {
			   StatusCode = HttpStatusCode.Unauthorized,
			   Content = new StringContent("Unauthorized")
		   });

		var httpClient = new HttpClient(handlerMock.Object);
		var authService = new AuthService(httpClient);

		
		await Assert.ThrowsAsync<Exception>(async () =>
			await authService.LoginAsync(_username, "wrongpassword"));
	}

	[Fact]
	public void SetAuthorizationHeader_ShouldSetCorrectToken()
	{
		
		var httpClient = new HttpClient();
		var authService = new AuthService(httpClient);

		
		authService.SetAuthorizationHeader(_validToken);

		
		Assert.Equal("Bearer", httpClient.DefaultRequestHeaders.Authorization.Scheme);
		Assert.Equal(_validToken, httpClient.DefaultRequestHeaders.Authorization.Parameter);
	}
}
