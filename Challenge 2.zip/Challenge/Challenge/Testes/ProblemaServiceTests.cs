using Xunit;
using Moq;
using Challenge.Services;
using Challenge.Repositories;
using Challenge.Models;
using System.Threading.Tasks;

public class ProblemaServiceTests
{
    private readonly ProblemaService _problemaService;
    private readonly Mock<IProblemaRepository> _problemaRepositoryMock;

    public ProblemaServiceTests()
    {
        _problemaRepositoryMock = new Mock<IProblemaRepository>();
        _problemaService = new ProblemaService(_problemaRepositoryMock.Object);
    }

    [Fact]
    public async Task DeveAdicionarProblemaCorretamente()
    {
        // Arrange
        var problema = new Problema { Id = 1, Descricao = "Novo problema" };

        // Act
        await _problemaService.AddProblemaAsync(problema);

        // Assert
        _problemaRepositoryMock.Verify(repo => repo.AddAsync(problema), Times.Once);
    }

    [Fact]
    public async Task DeveRetornarTodosProblemas()
    {
        // Arrange
        _problemaRepositoryMock.Setup(repo => repo.GetAllAsync()).ReturnsAsync(new List<Problema>());

        // Act
        var result = await _problemaService.GetAllProblemasAsync();

        // Assert
        Assert.NotNull(result);
        _problemaRepositoryMock.Verify(repo => repo.GetAllAsync(), Times.Once);
    }
}
