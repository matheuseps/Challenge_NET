using Xunit;
using Moq;
using Challenge.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using Challenge.Models;

public class AccountControllerTests
{
	private readonly Mock<SignInManager<IdentityUser>> _signInManagerMock;
	private readonly AccountController _controller;

	public AccountControllerTests()
	{
		var userStoreMock = new Mock<IUserStore<IdentityUser>>();
		var userManagerMock = new Mock<UserManager<IdentityUser>>(userStoreMock.Object, null, null, null, null, null, null, null, null);
		_signInManagerMock = new Mock<SignInManager<IdentityUser>>(userManagerMock.Object, null, null, null, null, null, null);
		_controller = new AccountController(_signInManagerMock.Object);
	}

	[Fact]
	public async Task Login_DeveRetornarRedirectQuandoSucesso()
	{
		// Arrange
		_signInManagerMock.Setup(s => s.PasswordSignInAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), false))
						  .ReturnsAsync(SignInResult.Success);

		// Act
		var result = await _controller.Login("usuario@teste.com", "senha123", false);

		// Assert
		var redirectResult = Assert.IsType<RedirectToActionResult>(result);
		Assert.Equal("Index", redirectResult.ActionName);
	}

	[Fact]
	public async Task Logout_DeveRedirecionarParaLogin()
	{
		// Act
		var result = await _controller.Logout();

		// Assert
		var redirectResult = Assert.IsType<RedirectToActionResult>(result);
		Assert.Equal("Login", redirectResult.ActionName);
	}
}
