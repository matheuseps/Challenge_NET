using Xunit;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Challenge;
using Newtonsoft.Json;
using Challenge.Models;
using System.Text;

namespace Challenge.Tests
{
	public class UsuarioControllerTests : IClassFixture<WebApplicationFactory<Startup>>
	{
		private readonly HttpClient _client;

		public UsuarioControllerTests(WebApplicationFactory<Startup> factory)
		{
			_client = factory.CreateClient();
		}

		[Fact]
		public async Task Get_ReturnsListOfUsuarios()
		{
			// Act
			var response = await _client.GetAsync("/api/usuario");

			// Assert
			response.EnsureSuccessStatusCode();
			var responseString = await response.Content.ReadAsStringAsync();
			var usuarios = JsonConvert.DeserializeObject<List<USUARIO>>(responseString);
			Assert.NotEmpty(usuarios);
		}

		[Fact]
		public async Task Post_AddsNewUsuario()
		{
			// Arrange
			var newUsuario = new USUARIO { IdUsuario = "3", Nome = "User3" };
			var content = new StringContent(JsonConvert.SerializeObject(newUsuario), Encoding.UTF8, "application/json");

			// Act
			var response = await _client.PostAsync("/api/usuario", content);

			// Assert
			response.EnsureSuccessStatusCode();
			var responseString = await response.Content.ReadAsStringAsync();
			var createdUsuario = JsonConvert.DeserializeObject<USUARIO>(responseString);
			Assert.Equal(newUsuario.Nome, createdUsuario.Nome);
		}
	}
}
