using Xunit;
using Moq;
using Challenge.Repositories;
using Challenge.Services;
using Challenge.Models;
using System.Collections.Generic;

namespace Challenge.Tests
{
    public class UsuarioServiceTests
    {
        private readonly Mock<IUsuarioRepository> _usuarioRepositoryMock;
        private readonly UsuarioService _usuarioService;

        public UsuarioServiceTests()
        {
            _usuarioRepositoryMock = new Mock<IUsuarioRepository>();
            _usuarioService = new UsuarioService(_usuarioRepositoryMock.Object);
        }

        [Fact]
        public void GetAllUsuarios_ShouldReturnAllUsuarios()
        {
            // Arrange
            var expectedUsuarios = new List<USUARIO>
            {
                new USUARIO { IdUsuario = "1", Nome = "User1" },
                new USUARIO { IdUsuario = "2", Nome = "User2" }
            };

            _usuarioRepositoryMock.Setup(repo => repo.GetAllUsuarios()).Returns(expectedUsuarios);

            // Act
            var result = _usuarioService.GetAllUsuarios();

            // Assert
            Assert.Equal(expectedUsuarios, result);
            _usuarioRepositoryMock.Verify(repo => repo.GetAllUsuarios(), Times.Once);
        }

        [Fact]
        public void GetUsuarioById_ShouldReturnUsuario_WhenUsuarioExists()
        {
            // Arrange
            var userId = "1";
            var expectedUsuario = new USUARIO { IdUsuario = userId, Nome = "User1" };
            _usuarioRepositoryMock.Setup(repo => repo.GetUsuarioById(userId)).Returns(expectedUsuario);

            // Act
            var result = _usuarioService.GetUsuarioById(userId);

            // Assert
            Assert.Equal(expectedUsuario, result);
            _usuarioRepositoryMock.Verify(repo => repo.GetUsuarioById(userId), Times.Once);
        }

        [Fact]
        public void GetUsuarioById_ShouldReturnNull_WhenUsuarioDoesNotExist()
        {
            // Arrange
            var userId = "99";
            _usuarioRepositoryMock.Setup(repo => repo.GetUsuarioById(userId)).Returns((USUARIO)null);

            // Act
            var result = _usuarioService.GetUsuarioById(userId);

            // Assert
            Assert.Null(result);
            _usuarioRepositoryMock.Verify(repo => repo.GetUsuarioById(userId), Times.Once);
        }
    }
}
