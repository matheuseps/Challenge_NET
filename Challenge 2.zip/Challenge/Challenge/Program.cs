using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Challenge;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace Challenge
{
    public class Program
    {
        public static void Main(string[] args) => CreateHostBuilder(args).Build().Run();

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }

    // Classe AuthService para integra��o com o servi�o externo
    public class AuthService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiUrl = "https://api.seuservico.com/auth"; // URL do servi�o externo de autentica��o

        public AuthService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> LoginAsync(string username, string password)
        {
            // Configurar o objeto de requisi��o com o login e senha
            var requestBody = new
            {
                username = username,
                password = password
            };

            // Serializar o corpo da requisi��o para JSON
            var jsonContent = JsonConvert.SerializeObject(requestBody);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Enviar a requisi��o POST para a URL de login
            var response = await _httpClient.PostAsync($"{_apiUrl}/login", content);

            // Verificar o status da resposta
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Erro ao autenticar");
            }

            // Ler o token JWT do corpo da resposta
            var responseContent = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<AuthResponse>(responseContent);

            return result.Token;
        }

        public void SetAuthorizationHeader(string token)
        {
            // Define o token JWT no cabe�alho "Authorization" para futuras requisi��es
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
    }

    // Classe auxiliar para deserializar a resposta de autentica��o
    public class AuthResponse
    {
        [JsonProperty("token")]
        public string Token { get; set; }
    }

    // Classe Startup para configura��o do servi�o e inje��o de depend�ncias
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpClient<AuthService>(); // Adiciona o AuthService ao DI
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
