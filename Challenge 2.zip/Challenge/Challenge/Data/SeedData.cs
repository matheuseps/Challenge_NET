﻿using Challenge.Models;
using Challenge.NovaPasta;

namespace Challenge.Data
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                // Verifica se já existem registros na tabela Problemas
                if (context.Problemas.Any())
                {
                    return;   // O banco de dados já foi preenchido, então sai do método
                }

                // Insere dados iniciais na tabela Problemas
                context.Problemas.AddRange(
                    new Problema
                    {
                        Titulo = "Exemplo de Problema 1",
                        Descricao = "Descrição do Problema 1",
                        Dificuldade = Dificuldade.Facil
                    },
                    new Problema
                    {
                        Titulo = "Exemplo de Problema 2",
                        Descricao = "Descrição do Problema 2",
                        Dificuldade = Dificuldade.Medio
                    },
                    new Problema
                    {
                        Titulo = "Exemplo de Problema 3",
                        Descricao = "Descrição do Problema 3",
                        Dificuldade = Dificuldade.Dificil
                    }
                );
                context.SaveChanges(); // Salva as alterações no banco de dados
            }
        }
    }
}