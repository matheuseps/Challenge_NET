﻿using Challenge.Models;
using System.Collections.Generic;

namespace Challenge.Data
{
    public class DbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public DbContext(DbContextOptions<DbContext> options) : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Cadastro> Cadastros { get; set; }
        public DbSet<Problema> Problemas { get; set; }
    }
}