﻿using Microsoft.Data.SqlClient;

namespace Challenge.Repositories
{
    public class MyService
    {
        private readonly string _connectionString;

        public MyService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public void DoWork()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                // Execute suas operações com o banco de dados aqui
            }
        }
    }
}