﻿using Challenge.Models;

public interface IProblemaRepository
{
    Task<IEnumerable<PROBLEMA>> GetAllProblemasAsync();
    Task<PROBLEMA> GetProblemaByIdAsync(int id);
    Task CreateProblemaAsync(PROBLEMA problema);
    Task UpdateProblemaAsync(PROBLEMA problema);
    Task DeleteProblemaAsync(int id);
}
