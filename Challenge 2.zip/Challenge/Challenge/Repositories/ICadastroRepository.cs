﻿using Challenge.Models;

public interface ICadastroRepository
{
    Task<IEnumerable<CADASTRO>> GetAllCadastrosAsync();
    Task<CADASTRO> GetCadastroByIdAsync(int id);
    Task CreateCadastroAsync(CADASTRO cadastro);
    Task UpdateCadastroAsync(CADASTRO cadastro);
    Task DeleteCadastroAsync(int id);  // Altere para int
}
