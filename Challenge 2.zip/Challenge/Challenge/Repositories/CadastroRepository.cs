﻿using Challenge.Data;
using Challenge.Models;
using Microsoft.EntityFrameworkCore;

public class CadastroRepository : ICadastroRepository
{
    private readonly ApplicationDbContext _context;

    public CadastroRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<IEnumerable<CADASTRO>> GetAllCadastrosAsync()
    {
        return await _context.Cadastros.ToListAsync();
    }

    public async Task<CADASTRO> GetCadastroByIdAsync(int id)
    {
        return await _context.Cadastros.FindAsync(id);
    }

    public async Task CreateCadastroAsync(CADASTRO cadastro)
    {
        if (cadastro == null) throw new ArgumentNullException(nameof(cadastro));

        _context.Cadastros.Add(cadastro);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateCadastroAsync(CADASTRO cadastro)
    {
        if (cadastro == null) throw new ArgumentNullException(nameof(cadastro));

        _context.Entry(cadastro).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }

    public async Task DeleteCadastroAsync(int id)
    {
        var cadastro = await _context.Cadastros.FindAsync(id);
        if (cadastro != null)
        {
            _context.Cadastros.Remove(cadastro);
            await _context.SaveChangesAsync();
        }
    }
}
