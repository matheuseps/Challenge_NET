﻿using Challenge.Data;
using Challenge.Models;
using System.Collections.Generic;
using System.Linq;

namespace Challenge.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly ApplicationDbContext _context;

        public UsuarioRepository(ApplicationDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public IEnumerable<USUARIO> GetAll()
        {
            return _context.Usuarios.ToList();
        }

        public USUARIO GetById(string id)
        {
            return _context.Usuarios.Find(id);
        }

        public void Add(USUARIO usuario)
        {
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();
        }

        public void Update(USUARIO usuario)
        {
            _context.Usuarios.Update(usuario);
            _context.SaveChanges();
        }

        public void Delete(string id)
        {
            var usuario = GetById(id);
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
                _context.SaveChanges();
            }
        }
    }
}
