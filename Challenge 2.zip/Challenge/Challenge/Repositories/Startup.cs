﻿namespace Challenge.Repository
{
    public class Startup
    {
    }
}
