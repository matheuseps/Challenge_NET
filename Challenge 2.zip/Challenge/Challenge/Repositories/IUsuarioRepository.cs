﻿using Challenge.Models;

namespace Challenge.Repositories
{
    public interface IUsuarioRepository
    {
        IEnumerable<USUARIO> GetAll();
        USUARIO GetById(string id);
        void Add(USUARIO usuario);
        void Update(USUARIO usuario);
        void Delete(string id);
    }
}