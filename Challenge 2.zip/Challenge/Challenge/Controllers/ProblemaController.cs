﻿using Microsoft.AspNetCore.Mvc;
using Challenge.Models;
using Challenge.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProblemaController : ControllerBase
    {
        private readonly IProblemaService _problemaService;

        public ProblemaController(IProblemaService problemaService)
        {
            _problemaService = problemaService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PROBLEMA>>> GetProblemas()
        {
            var problemas = await _problemaService.GetAllProblemasAsync();
            return Ok(problemas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PROBLEMA>> GetProblema(int id)
        {
            var problema = await _problemaService.GetProblemaByIdAsync(id);

            if (problema == null)
            {
                return NotFound();
            }

            return problema;
        }

        [HttpPost]
        public async Task<ActionResult<PROBLEMA>> CreateProblema(PROBLEMA problema)
        {
            await _problemaService.CreateProblemaAsync(problema);
            return CreatedAtAction(nameof(GetProblema), new { id = problema.Id }, problema);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProblema(int id, PROBLEMA problema)
        {
            if (id != problema.Id)
            {
                return BadRequest();
            }

            await _problemaService.UpdateProblemaAsync(problema);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProblema(int id)
        {
            await _problemaService.DeleteProblemaAsync(id);
            return NoContent();
        }
    }
}
