﻿using Microsoft.AspNetCore.Mvc;
using Challenge.Models;
using Challenge.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CadastroController : ControllerBase
    {
        private readonly ICadastroService _cadastroService;

        public CadastroController(ICadastroService cadastroService)
        {
            _cadastroService = cadastroService;
        }

        // GET: api/Cadastro
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CADASTRO>>> GetCadastros()
        {
            var cadastros = await _cadastroService.GetAllCadastrosAsync();
            return Ok(cadastros);
        }

        // GET: api/Cadastro/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CADASTRO>> GetCadastro(int id)
        {
            var cadastro = await _cadastroService.GetCadastroByIdAsync(id);

            if (cadastro == null)
            {
                return NotFound();
            }

            return cadastro;
        }

        // POST: api/Cadastro
        [HttpPost]
        public async Task<ActionResult<CADASTRO>> CreateCadastro(CADASTRO cadastro)
        {
            await _cadastroService.CreateCadastroAsync(cadastro);
            return CreatedAtAction(nameof(GetCadastro), new { id = cadastro.IdUsuario }, cadastro);
        }

        // PUT: api/Cadastro/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCadastro(int id, CADASTRO cadastro)
        {
            if (id != cadastro.IdUsuario)
            {
                return BadRequest();
            }

            await _cadastroService.UpdateCadastroAsync(cadastro);

            return NoContent();
        }

        // DELETE: api/Cadastro/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCadastro(int id)
        {
            await _cadastroService.DeleteCadastroAsync(id);
            return NoContent();
        }
    }
}
