﻿using Challenge.Models;
using Challenge.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService ?? throw new ArgumentNullException(nameof(usuarioService));
        }

        [HttpGet]
        public ActionResult<IEnumerable<USUARIO>> GetAllUsuarios()
        {
            var usuarios = _usuarioService.GetAllUsuarios();
            return Ok(usuarios);
        }

        [HttpGet("{id}")]
        public ActionResult<USUARIO> GetUsuarioById(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return BadRequest("ID do usuário é inválido.");

            var usuario = _usuarioService.GetUsuarioById(id);
            if (usuario == null) return NotFound($"Usuário com ID {id} não encontrado.");

            return Ok(usuario);
        }

        [HttpPost]
        public ActionResult<USUARIO> CreateUsuario([FromBody] USUARIO usuario)
        {
            if (usuario == null) return BadRequest("Dados do usuário são inválidos.");

            _usuarioService.AddUsuario(usuario);
            return CreatedAtAction(nameof(GetUsuarioById), new { id = usuario.IdUsuario }, usuario);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUsuario(string id, [FromBody] USUARIO usuario)
        {
            if (usuario == null || id != usuario.IdUsuario)
                return BadRequest("ID do usuário é inválido ou não corresponde aos dados.");

            var usuarioExistente = _usuarioService.GetUsuarioById(id);
            if (usuarioExistente == null) return NotFound($"Usuário com ID {id} não encontrado.");

            _usuarioService.UpdateUsuario(usuario);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUsuario(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return BadRequest("ID do usuário é inválido.");

            var usuarioExistente = _usuarioService.GetUsuarioById(id);
            if (usuarioExistente == null) return NotFound($"Usuário com ID {id} não encontrado.");

            _usuarioService.DeleteUsuario(id);
            return NoContent();
        }
    }
}
