using Challenge.Services;
using Microsoft.AspNetCore.Mvc;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecommendationController : ControllerBase
    {
        private readonly RecommendationService _recommendationService;

        public RecommendationController(RecommendationService recommendationService)
        {
            _recommendationService = recommendationService;
        }

        [HttpGet("recommend")]
        public ActionResult<float> Recommend(string userId, string productId)
        {
            var score = _recommendationService.Predict(userId, productId);
            return Ok(score);
        }
    }
}
