﻿namespace Challenge.Models
{
    public class PROBLEMA
    {
        public int Id { get; set; }
        public string NomeSite { get; set; }
        public string ProblemaDescricao { get; set; }
        public string Dificuldade { get; set; }
    }
}
