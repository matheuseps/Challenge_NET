﻿using System.ComponentModel.DataAnnotations;

namespace Challenge.Models
{
    public class Feedback
    {
        [Key]
        public string IdUsuario { get; set; }

        [Required]
        [MaxLength(100)]
        public string NomeSite { get; set; }

        [MaxLength(1000)]
        public string Melhorias { get; set; }

        [Range(0, 99)]
        public int NtFuncionamento { get; set; }

        [Range(0, 99)]
        public int NtFacilidade { get; set; }

        [Range(0, 99)]
        public int NtDificuldade { get; set; }
    }
}
