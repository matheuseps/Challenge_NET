﻿namespace Challenge.Models
{
    public class USUARIO
    {
        public string IdUsuario { get; set; }
        public string CPF { get; set; }
        public string Nome { get; set; }
        public string RG { get; set; }
        public string Senha { get; set; }
    }
}