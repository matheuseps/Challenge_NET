﻿namespace Challenge.Models
{
    public class CADASTRO
    {
        public int IdUsuario { get; set; }
        public string NomeSite { get; set; }
        public string ServicoSite { get; set; }
        public string EmailSite { get; set; }
        public decimal TelefoneSite { get; set; }
    }
}
