﻿using Challenge.Models;
using Challenge.NovaPasta;

namespace Challenge.NovaPasta2
{
    public class CadastroService
    {
        private readonly ApplicationDbContext _context;

        public CadastroService(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Cadastro> GetAllCadastros()
        {
            return _context.Cadastros.ToList();
        }

        public Cadastro GetCadastroById(int id)
        {
            return _context.Cadastros.Find(id);
        }

        public void AddCadastro(Cadastro cadastro)
        {
            _context.Cadastros.Add(cadastro);
            _context.SaveChanges();
        }

        public void UpdateCadastro(Cadastro cadastro)
        {
            _context.Cadastros.Update(cadastro);
            _context.SaveChanges();
        }

        public void DeleteCadastro(int id)
        {
            var cadastro = _context.Cadastros.Find(id);
            if (cadastro != null)
            {
                _context.Cadastros.Remove(cadastro);
                _context.SaveChanges();
            }
        }
    }
}