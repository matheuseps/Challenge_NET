﻿using Challenge.Models;
using Challenge.NovaPasta;
using Challenge.Repositories;

namespace Challenge.NovaPasta2
{
    public interface IProblemaService
    {
        Task<IEnumerable<Problema>> GetAllProblemasAsync();
        Task<Problema> GetProblemaByIdAsync(int id);
        Task<Problema> AddProblemaAsync(Problema problema);
        Task<Problema> UpdateProblemaAsync(Problema problema);
        Task<bool> DeleteProblemaAsync(int id);
    }

    public class ProblemaService : IProblemaService
    {
        private readonly IProblemaRepository _problemaRepository;

        public ProblemaService(IProblemaRepository problemaRepository)
        {
            _problemaRepository = problemaRepository;
        }

        public async Task<IEnumerable<Problema>> GetAllProblemasAsync()
        {
            return await _problemaRepository.GetAllAsync();
        }

        public async Task<Problema> GetProblemaByIdAsync(int id)
        {
            return await _problemaRepository.GetByIdAsync(id);
        }

        public async Task<Problema> AddProblemaAsync(Problema problema)
        {
            return await _problemaRepository.AddAsync(problema);
        }

        public async Task<Problema> UpdateProblemaAsync(Problema problema)
        {
            return await _problemaRepository.UpdateAsync(problema);
        }

        public async Task<bool> DeleteProblemaAsync(int id)
        {
            return await _problemaRepository.DeleteAsync(id);
        }
    }
}