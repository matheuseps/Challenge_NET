namespace Challenge.ML
{
    public class SentimentoData
    {
        public string Texto { get; set; }
        public bool Sentimento { get; set; }
    }

    public class SentimentoPrediction
    {
        public bool Prediction { get; set; }
        public float Probability { get; set; }
        public float Score { get; set; }
    }
}
