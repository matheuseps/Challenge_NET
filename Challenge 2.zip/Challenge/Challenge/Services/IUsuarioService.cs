﻿using Challenge.Models;
using System.Collections.Generic;

namespace Challenge.Services
{
    public interface IUsuarioService
    {
        IEnumerable<USUARIO> GetAllUsuarios();
        USUARIO GetUsuarioById(string id);
        void AddUsuario(USUARIO usuario);
        void UpdateUsuario(USUARIO usuario);
        void DeleteUsuario(string id);
    }
}