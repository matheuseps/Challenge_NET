﻿using Challenge.Models;
using Challenge.Repositories;
using System;
using System.Collections.Generic;

namespace Challenge.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly IUsuarioRepository _usuarioRepository;

        public UsuarioService(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository ?? throw new ArgumentNullException(nameof(usuarioRepository));
        }

        public IEnumerable<USUARIO> GetAllUsuarios()
        {
            return _usuarioRepository.GetAll();
        }

        public USUARIO GetUsuarioById(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentException("O ID do usuário não pode estar vazio.", nameof(id));

            var usuario = _usuarioRepository.GetById(id);
            if (usuario == null)
                throw new KeyNotFoundException($"Usuário com ID {id} não encontrado.");

            return usuario;
        }

        public void AddUsuario(USUARIO usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException(nameof(usuario), "Usuário não pode ser nulo.");

            _usuarioRepository.Add(usuario);
        }

        public void UpdateUsuario(USUARIO usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException(nameof(usuario), "Usuário não pode ser nulo.");

            var usuarioExistente = _usuarioRepository.GetById(usuario.IdUsuario);
            if (usuarioExistente == null)
                throw new KeyNotFoundException($"Usuário com ID {usuario.IdUsuario} não encontrado.");

            _usuarioRepository.Update(usuario);
        }

        public void DeleteUsuario(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentException("O ID do usuário não pode estar vazio.", nameof(id));

            var usuario = _usuarioRepository.GetById(id);
            if (usuario == null)
                throw new KeyNotFoundException($"Usuário com ID {id} não encontrado.");

            _usuarioRepository.Delete(id);
        }
    }
}
