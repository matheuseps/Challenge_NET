using Microsoft.ML;
using Microsoft.ML.Data;
using System.Collections.Generic;
using System.Linq;

namespace Challenge.Services
{
    public class RecommendationService
    {
        private readonly MLContext _mlContext;
        private ITransformer _model;

        public RecommendationService(MLContext mlContext)
        {
            _mlContext = mlContext;
            TreinarModelo(); // Inicializa o modelo no construtor
        }

        // M�todo para treinar um modelo b�sico de recomenda��o
        private void TreinarModelo()
        {
            var data = new List<RecommendationData>
            {
                // Exemplo de dados de treinamento: substitua pelos dados reais
                new RecommendationData { UserId = "1", ProductId = "101", Label = 1 },
                new RecommendationData { UserId = "1", ProductId = "102", Label = 0 },
                // Adicione mais dados aqui
            };

            var trainingData = _mlContext.Data.LoadFromEnumerable(data);

            var pipeline = _mlContext.Transforms.Conversion
                .MapValueToKey("UserId")
                .Append(_mlContext.Transforms.Conversion.MapValueToKey("ProductId"))
                .Append(_mlContext.Recommendation().Trainers.MatrixFactorization("UserId", "ProductId", labelColumnName: "Label"));

            _model = pipeline.Fit(trainingData);
        }

        // M�todo para fazer uma recomenda��o com o modelo treinado
        public float Predict(string userId, string productId)
        {
            var predictionEngine = _mlContext.Model.CreatePredictionEngine<RecommendationData, RecommendationPrediction>(_model);
            var prediction = predictionEngine.Predict(new RecommendationData { UserId = userId, ProductId = productId });
            return prediction.Score;
        }
    }

    // Classe de dados de entrada para o modelo
    public class RecommendationData
    {
        public string UserId { get; set; }
        public string ProductId { get; set; }
        public float Label { get; set; }
    }

    // Classe de dados de sa�da para a previs�o
    public class RecommendationPrediction
    {
        public float Score { get; set; }
    }
}
