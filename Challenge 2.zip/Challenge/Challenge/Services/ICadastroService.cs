﻿using Challenge.Models;

namespace Challenge.Services
{
    public interface ICadastroService
    {
        Task<IEnumerable<CADASTRO>> GetAllCadastrosAsync();
        Task<CADASTRO> GetCadastroByIdAsync(int id);
        Task CreateCadastroAsync(CADASTRO cadastro);
        Task UpdateCadastroAsync(CADASTRO cadastro);
        Task DeleteCadastroAsync(int id);
    }
}
