﻿using Challenge.Models;
using Challenge.Repositories;

namespace Challenge.Services
{
    public class ProblemaService : IProblemaService
    {
        private readonly IProblemaRepository _problemaRepository;

        public ProblemaService(IProblemaRepository problemaRepository)
        {
            _problemaRepository = problemaRepository;
        }

        public async Task<IEnumerable<PROBLEMA>> GetAllProblemasAsync()
        {
            return await _problemaRepository.GetAllProblemasAsync();
        }

        public async Task<PROBLEMA> GetProblemaByIdAsync(int id)
        {
            return await _problemaRepository.GetProblemaByIdAsync(id);
        }

        public async Task CreateProblemaAsync(PROBLEMA problema)
        {
            await _problemaRepository.CreateProblemaAsync(problema);
        }

        public async Task UpdateProblemaAsync(PROBLEMA problema)
        {
            await _problemaRepository.UpdateProblemaAsync(problema: problema);
        }

        public async Task DeleteProblemaAsync(int id)
        {
            await _problemaRepository.DeleteProblemaAsync(id);
        }
    }
}
