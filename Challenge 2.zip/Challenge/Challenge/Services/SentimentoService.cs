using Microsoft.ML;
using Microsoft.ML.Data;

namespace Challenge.ML
{
    public class SentimentoService
    {
        private readonly MLContext _mlContext;
        private readonly ITransformer _modelo;

        public SentimentoService()
        {
            _mlContext = new MLContext();
            var dadosTreinamento = LoadTrainingData();
            var pipeline = _mlContext.Transforms.Text.FeaturizeText("Features", nameof(SentimentoData.Texto))
                .Append(_mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: nameof(SentimentoData.Sentimento), featureColumnName: "Features"));
            _modelo = pipeline.Fit(dadosTreinamento);
        }

        private IDataView LoadTrainingData()
        {
            var dados = new[]
            {
                new SentimentoData { Texto = "Eu amo este produto", Sentimento = true },
                new SentimentoData { Texto = "Isso � terr�vel", Sentimento = false },
                // Adicione mais exemplos para um modelo mais robusto
            };
            return _mlContext.Data.LoadFromEnumerable(dados);
        }

        public SentimentoPrediction Predict(string texto)
        {
            var predicaoEngine = _mlContext.Model.CreatePredictionEngine<SentimentoData, SentimentoPrediction>(_modelo);
            return predicaoEngine.Predict(new SentimentoData { Texto = texto });
        }
    }
}
