using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class AuthService
{
    private readonly HttpClient _httpClient;
    private readonly string _apiUrl = "https://api.seuservico.com/auth"; // URL do servi�o externo de autentica��o

    public AuthService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string> LoginAsync(string username, string password)
    {
        
        var requestBody = new
        {
            username = username,
            password = password
        };

        
        var jsonContent = JsonConvert.SerializeObject(requestBody);
        var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

        
        var response = await _httpClient.PostAsync($"{_apiUrl}/login", content);

        
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Erro ao autenticar");
        }

        
        var responseContent = await response.Content.ReadAsStringAsync();
        var result = JsonConvert.DeserializeObject<AuthResponse>(responseContent);

        return result.Token;
    }

    public void SetAuthorizationHeader(string token)
    {
        
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }
}


public class AuthResponse
{
    [JsonProperty("token")]
    public string Token { get; set; }
}
